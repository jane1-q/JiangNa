# chapter6\chapter6\models.py
from django.db import models


class chess(models.Model):
    name = models.CharField(max_length=8)  # 棋子名称
    detail = models.CharField(max_length=8)  # 棋子介绍
