﻿#chapter4\helloworld\helloworld\models.py
from django.db import models
class sysuser(models.Model):
    username=models.CharField(max_length=20,unique=True) #用户名
    password=models.CharField(max_length=20)#密码