"""
Package for myVsDjango.
"""
