from django.http import HttpResponse
def index(request):
    html='这是我的第一个Django网页！<br/><img src="/static/pic1.png" alt="no picture" width="220" height="220">'
    return HttpResponse(html)
